SURYANSH TYPING — Learning Lessons + Login

Updates:
- Heading changed to “100 Learning Lessons”.
- Added sign in / create account UI with username, email, website password, and Google sign-in.
- Footer: © 2026 SURYANSH TYPING ALL RIGHT RESERVED AND SECURE BY https://suryanshpratapsingh.wixsite.com/suryansh
- Hacker Matrix theme and existing typing lessons retained.

IMPORTANT — Enable real authentication:
This project uses Firebase Authentication. It will NOT authenticate real accounts until the site owner configures it:
1. Create a project at https://console.firebase.google.com/
2. Add a Web app and copy its Firebase config.
3. In index.html, replace the four placeholder values in `firebaseConfig` (apiKey, authDomain, projectId, appId) with your actual values.
4. Firebase Console → Authentication → Sign-in method: enable Email/Password and Google.
5. Add your deployed website domain under Authentication → Settings → Authorized domains.
6. Deploy on HTTPS or test via a local development server. ES modules may not work when opened directly as file://.

Security note: The website password is a password created for SURYANSH TYPING, not the user's Google/Gmail password. Never ask users to enter their Google password into your site. Google sign-in uses Google's secure popup.

The typing lesson progress remains local to the browser in this version. Firebase login is included but requires the configuration above before it works.
